'use strict';

/**
 * Route configuration for the RDash module.
 */
angular.module('RDash').config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        // For unmatched routes
        $urlRouterProvider.otherwise('/login');

        // Application routes
        $stateProvider
            .state('index', {
                url: '/',
                templateUrl: 'templates/principalView.html',
                controller: 'principalCtrl'
            })
            .state('login', {
                url: '/login',
                templateUrl: 'templates/loginView.html',
                controller: 'loginCtrl'
            })
            .state('nuevo', {
                url: '/nuevo',
                templateUrl: 'templates/nuevoIncidenteView.html',
                controller: 'nuevoIncidenteCtrl'
            })
            .state('editar', {
                url: '/editar/:id',
                templateUrl: 'templates/editIncidenteView.html',
                controller: 'editIncidenteCtrl'
            })
            .state('tablero1', {
                url: '/tablero1',
                templateUrl: 'templates/tablero1View.html',
                controller: 'tablero1Ctrl'
            })
            .state('tablero1.plataforma', {
                views:{
                    'plataforma':{
                        templateUrl: 'templates/plataforma-brigada.view.html',
                        controller: 'plataformaBrigadaCtrl'
                    }
                }
            })
            .state('tablero2', {
                url: '/tablero2',
                templateUrl: 'templates/tablero2View.html',
                controller: 'tablero2Ctrl'
            })
            .state('cargaarchivo', {
                url: '/cargaarchivo',
                templateUrl: 'templates/carga-archivo.view.html',
                controller: 'cargaArchivoView'
            })
            .state('test', {
                url: '/test',
                views:{
                    '':{
                        templateUrl: 'templates/busqueda.view.html',
                        controller: 'busquedaCtrl'
                    }
                }
            })
            .state('consulta', {
                url: '/consulta',
                views:{
                    '':{
                        templateUrl: 'templates/busqueda.view.html',
                        controller: 'busquedaCtrl'
                    }
                }
            })
            .state('tableroMapa', {
                url: '/tabmap',
                templateUrl: 'templates/tablero-mapa.view.html',
                controller: 'tableroMapaCtrl'
            })
            .state('tableroCenso', {
                url: '/tabcen',
                templateUrl: 'templates/tablero-censo.view.html'
            })
            .state('tableroMaster', {
                url: '/tabmas',
                views:{
                    '':{
                        templateUrl: 'templates/tablero-maestro.view.html',
                    },
                    'seccionPadron@tableroMaster':{
                        templateUrl: 'templates/seccion-padron.view.html',
                    },
                    'seccionAreas@tableroMaster':{
                        templateUrl: 'templates/seccion-areas.view.html',
                    },
                    'seccionIniciativas@tableroMaster':{
                        templateUrl: 'templates/seccion-iniciativas.view.html',
                    },
                    'seccionResumen@tableroMaster':{
                        templateUrl: 'templates/seccion-resumen.view.html',
                    },
                    'tableroCenso@tableroMaster':{
                        templateUrl: 'templates/tablero-censo.view.html',
                        controller: 'tableroCensoCtrl',
                    },
                    'tableroDictamen@tableroMaster':{
                        templateUrl: 'templates/tablero-dictamen.view.html',
                        controller: 'tableroDictamenCtrl',
                    },
                    'tableroAreaCartera@tableroMaster':{
                        templateUrl: 'templates/tablero-area-cartera.view.html',
                        controller: 'tableroAreaCarteraCtrl',
                    },
                    'tableroAreaRH@tableroMaster':{
                        templateUrl: 'templates/tablero-area-rh.view.html',
                        controller: 'tableroAreaRHCtrl',
                    },
                    'tableroAreaDel@tableroMaster':{
                        templateUrl: 'templates/tablero-area-del.view.html',
                        controller: 'tableroAreaDelCtrl',
                    },
                    'tableroAreaAtencion@tableroMaster':{
                        templateUrl: 'templates/tablero-area-atencion.view.html',
                        controller: 'tableroAtnSrvCtrl',
                    },
                    'tableroIniciativaMonto@tableroMaster':{
                        templateUrl: 'templates/tablero-iniciativa-rentas.view.html',
                        controller: 'tableroIniciativaCtrl'
                    },
                    'notaInformativa@tableroMaster':{
                        templateUrl: 'templates/nota-informativa.view.html'
                    }
                }
            })

    }
]).filter('percentFilter', function () {
    return function (value, scope) {
        var res="";
        if(angular.isDefined(value)){
            if(angular.isDefined(value.toFixed)){
                res=(value.toFixed(1)) +" %";
            }else{
                res=value+" %";
            }

        }
        return res;
    };
});;


